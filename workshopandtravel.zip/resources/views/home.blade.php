@extends('layout.shell')
@section('content')

<div class="container-fluid">
@include('components.nav')
@include('components.slider')
@include ('destinations')
</div>

@endsection