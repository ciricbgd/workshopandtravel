<ul class="nav justify-content-end">
  <li class="nav-item">
    <a class="nav-link active" href="#">Početna</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Ture</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">O nama</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Kontakt</a>
  </li>
</ul>