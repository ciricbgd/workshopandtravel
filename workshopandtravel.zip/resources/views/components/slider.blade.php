<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
        <img class="d-block" src="{{url('/')}}/img/website/stargazing.jpg" alt="First slide">
        <div class="carousel-caption d-none d-md-block">
            <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sunt.</h5>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quaerat illum voluptate, consectetur sed non repellendus distinctio delectus ullam esse officia veritatis voluptates obcaecati possimus totam quis in fuga tempore incidunt.</p>
        </div>
    </div>
    <div class="carousel-item">
        <img class="d-block" src="{{url('/')}}/img/website/rafting.jpg" alt="Second slide">
        <div class="carousel-caption d-none d-md-block">
            <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sunt.</h5>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quaerat illum voluptate, consectetur sed non repellendus distinctio delectus ullam esse officia veritatis voluptates obcaecati possimus totam quis in fuga tempore incidunt.</p>
        </div>
    </div>
    <div class="carousel-item">
      <img class="d-block" src="{{url('/')}}/img/website/montenegro.jpg" alt="Third slide">
        <div class="carousel-caption d-none d-md-block">
            <h5>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, sunt.</h5>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quaerat illum voluptate, consectetur sed non repellendus distinctio delectus ullam esse officia veritatis voluptates obcaecati possimus totam quis in fuga tempore incidunt.</p>
        </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev" hidden>
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next" hidden>
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>